-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-05-2025 a las 23:02:14
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `panaderia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'Panes Básicos'),
(2, 'Panes Especiales'),
(3, 'Panes Típicos'),
(4, 'Panes Dulces');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `direccion`, `telefono`, `usuario_id`) VALUES
(1, 'Ana Torres', 'Calle 20 #15-22', '3123456789', 10058227),
(2, 'Andrés Nieto', 'Carrera 45 #67-89', '3209876543', 10058230),
(3, 'Diana Beltrán', 'Avenida Libertador #123', '3001122334', 10058233),
(4, 'Felipe Correa', 'Calle 8 #12-34', '3012233445', 10058236),
(5, 'Nicolás Franco', 'Avenida Brasil #56', '3023344556', 10058239),
(6, 'Juliana Vargas', 'Transversal 10 #98-76', '3034455667', 10058244),
(7, 'Natalia Pardo', 'Calle 57 #86-36', '3841080102', 10058248),
(8, 'Camilo Torres', 'Calle 14 #86-28', '3688872344', 10058251),
(9, 'Héctor Valdés', 'Calle 73 #81-26', '3897489600', 10058255),
(10, 'Pablo Reyes', 'Calle 34 #26-31', '3732907765', 10058259),
(11, 'Rodrigo Céspedes', 'Calle 19 #9-31', '3328723071', 10058263);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `medio_pago_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id`, `fecha`, `proveedor_id`, `usuario_id`, `medio_pago_id`) VALUES
(1, '2025-05-08', 1023, 10058221, 1),
(2, '2025-05-08', 1035, 10058223, 2),
(3, '2025-05-08', 1084, 10058225, 3),
(4, '2025-05-08', 2031, 10058226, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_compras`
--

CREATE TABLE `detalle_compras` (
  `id` int(11) NOT NULL,
  `compra_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_compras`
--

INSERT INTO `detalle_compras` (`id`, `compra_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES
(1, 1, 1, 10, 800.00),
(2, 1, 2, 5, 1000.00),
(3, 1, 3, 8, 1200.00),
(4, 2, 4, 6, 1800.00),
(5, 2, 5, 12, 1300.00),
(6, 2, 6, 15, 900.00),
(7, 3, 7, 7, 1500.00),
(8, 3, 8, 10, 1100.00),
(9, 3, 9, 9, 1000.00),
(10, 4, 10, 5, 2000.00),
(11, 4, 11, 6, 1400.00),
(12, 4, 12, 4, 1000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_venta`
--

CREATE TABLE `detalle_venta` (
  `id` int(11) NOT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_venta`
--

INSERT INTO `detalle_venta` (`id`, `venta_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES
(1, 1, 1, 2, 800.00),
(2, 1, 2, 1, 1000.00),
(3, 2, 4, 3, 1800.00),
(4, 3, 3, 2, 1200.00),
(5, 3, 5, 1, 1300.00),
(6, 4, 6, 2, 900.00),
(7, 4, 10, 1, 2000.00),
(8, 5, 7, 2, 1500.00),
(9, 5, 11, 1, 1400.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medios_pago`
--

CREATE TABLE `medios_pago` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `medios_pago`
--

INSERT INTO `medios_pago` (`id`, `tipo`) VALUES
(1, 'Efectivo'),
(2, 'Transferencia'),
(3, 'Tarjeta de crédito'),
(4, 'Cheque');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `stock`, `categoria_id`) VALUES
(1, 'Pan francés', 'Pan crujiente y dorado, ideal para desayunos', 800.00, 120, 1),
(2, 'Pan integral', 'Rico en fibra, elaborado con harina integral', 1000.00, 80, 1),
(3, 'Pan de queso', 'Suave pan con trozos de queso derretido', 1200.00, 100, 2),
(4, 'Croissant', 'Pan de hojaldre con mantequilla, estilo francés', 1800.00, 60, 2),
(5, 'Pan de bono', 'Tradicional panecillo con queso y almidón', 1300.00, 150, 3),
(6, 'Pan dulce', 'Pan con cubierta azucarada, ideal para la tarde', 900.00, 110, 4),
(7, 'Baguette', 'Pan largo y crujiente, típico de Francia', 1500.00, 50, 1),
(8, 'Pan de avena', 'Pan saludable con avena en su interior', 1100.00, 70, 1),
(9, 'Pan de maíz', 'Elaborado con harina de maíz, suave y sabroso', 1000.00, 90, 1),
(10, 'Mogolla chicharrona', 'Mogolla con trozos de chicharrón', 2000.00, 40, 3),
(11, 'Pan de coco', 'Pan dulce con ralladura de coco', 1400.00, 60, 4),
(12, 'Pan aliñado', 'Pan con mezcla de especias', 1000.00, 85, 2),
(13, 'Rosca de canela', 'Pan en espiral con canela y azúcar', 1600.00, 70, 4),
(14, 'Pan hojaldrado', 'Pan en capas finas de hojaldre', 1700.00, 65, 2),
(15, 'Almojábana', 'Pan suave y redondo hecho con queso', 1300.00, 95, 3),
(16, 'Pan pita', 'Pan plano ideal para rellenar', 900.00, 50, 1),
(17, 'Pan de centeno', 'Elaborado con harina de centeno, muy nutritivo', 1200.00, 55, 1),
(18, 'Pan de nueces', 'Pan dulce con trozos de nuez', 1500.00, 40, 4),
(19, 'Pan de chocolate', 'Pan dulce relleno de chocolate', 1800.00, 60, 4),
(20, 'Pan batido', 'Clásico pan de mantequilla, esponjoso', 950.00, 100, 1),
(21, 'Pan campesino', 'Rústico, con corteza dura y sabor tradicional', 1100.00, 45, 1),
(22, 'Pan con bocadillo', 'Pan suave relleno de guayaba', 1600.00, 80, 4),
(23, 'Pan con arequipe', 'Relleno de dulce de leche', 1600.00, 75, 4),
(24, 'Pan con pasas', 'Pan dulce con pasas en la masa', 1200.00, 60, 4),
(25, 'Pan toscano', 'Sin sal, típico del centro de Italia', 1400.00, 30, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_clientes`
--

CREATE TABLE `productos_clientes` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos_clientes`
--

INSERT INTO `productos_clientes` (`id`, `producto_id`, `cliente_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(6, 6, 6),
(7, 7, 7),
(8, 8, 8),
(9, 9, 9),
(10, 10, 10),
(11, 11, 11),
(12, 12, 1),
(13, 13, 2),
(14, 14, 3),
(15, 15, 4),
(16, 16, 5),
(17, 17, 6),
(18, 18, 7),
(19, 19, 8),
(20, 20, 9),
(21, 21, 10),
(22, 22, 11),
(23, 23, 1),
(24, 24, 2),
(25, 25, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `nombre`, `contacto`) VALUES
(1023, 'Panadería San Juan', 'contacto@sanjuan.com'),
(1035, 'Café y Pan', 'contacto@cafeypan.com'),
(1084, 'La Granja S.A.', 'lagranja@proveedores.com'),
(2031, 'Trigo del Valle', 'info@trigovalle.com'),
(2147, 'Productos Alfer', 'alfer@productos.com'),
(2176, 'Distribuciones Martínez', 'dmartinez@provee.com'),
(3102, 'Harinas López', 'ventas@harinaslopez.com'),
(3268, 'Distribuidora A&B', 'aby@distri.com'),
(3285, 'Azúcar La Blanca', 'blanca@azucar.com'),
(4217, 'Distribuidora Norte', 'norte@proveedores.com'),
(4372, 'Cereales Don Pedro', 'donpedro@cereales.com'),
(4398, 'Huevos Selectos', 'huevos@selectos.com'),
(5340, 'La Espiga de Oro', 'espiga@oro.com'),
(5409, 'Leche El Rancho', 'rancho@leche.com'),
(5483, 'Pan y Miel', 'contacto@panymiel.com'),
(6481, 'Molinos Andinos', 'andinos@molinos.com'),
(6542, 'Mantecas Finas', 'ventas@mantecasfinas.com'),
(6594, 'Proveedora Maya', 'maya@proveedora.com'),
(7529, 'Dulces del Sur', 'contacto@dulcessur.com'),
(7605, 'Panificadora Colonial', 'colonial@pan.com'),
(7671, 'Panadería Central', 'central@pan.com'),
(8690, 'Frutas Selectas', 'frutas@selectas.com'),
(8793, 'Sabor Tradicional', 'info@sabortradicional.com'),
(9053, 'Cacao Real', 'real@cacao.com'),
(9812, 'Insumos Rivera', 'rivera@insumos.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id`, `nombre`) VALUES
(1, 'Vendedor'),
(2, 'Cajero'),
(3, 'Administración'),
(4, 'Cliente');

--
-- Disparadores `rol`
--
DELIMITER $$
CREATE TRIGGER `prevenir_creacion_administracion` BEFORE INSERT ON `rol` FOR EACH ROW BEGIN
    -- Verifica si el nombre insertado es 'Administración'
    IF LOWER(NEW.nombre) = 'administración' AND CURRENT_USER() NOT IN ('admin@localhost') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '? No tienes permiso para crear el rol Administración.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `rol_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `rol_id`) VALUES
(10058221, 'Julian Andrew C', 'julianchamaro@...', '12345', 1),
(10058223, 'David daza', 'daviddaz@gmail.com', '123456', 2),
(10058224, 'jaider sogamoso', 'jaiders@gmail.com', '1234567', 3),
(10058225, 'Laura Martínez', 'lauram@example.com', '12345', 1),
(10058226, 'Carlos López', 'carlosl@example.com', '23456', 2),
(10058227, 'Ana Torres', 'ana.t@example.com', '34567', 4),
(10058228, 'Luis Gómez', 'luisg@example.com', '45678', 1),
(10058229, 'Marta Díaz', 'martad@example.com', '56789', 2),
(10058230, 'Andrés Nieto', 'andresn@example.com', '67890', 4),
(10058231, 'Camila Ruiz', 'camilar@example.com', '78901', 1),
(10058232, 'Juan Pérez', 'juanp@example.com', '89012', 2),
(10058233, 'Diana Beltrán', 'dianab@example.com', '90123', 4),
(10058234, 'Pedro Castillo', 'pedroc@example.com', '11223', 1),
(10058235, 'Valentina Ríos', 'valenr@example.com', '22334', 2),
(10058236, 'Felipe Correa', 'felipec@example.com', '33445', 4),
(10058237, 'Esteban Ramírez', 'estebanr@example.com', '44556', 1),
(10058238, 'Lorena Silva', 'lorenas@example.com', '55667', 2),
(10058239, 'Nicolás Franco', 'nicof@example.com', '66778', 4),
(10058240, 'Tatiana Roldán', 'tatianar@example.com', '77889', 1),
(10058241, 'Santiago Medina', 'santiagom@example.com', '88990', 2),
(10058242, 'Manuela Cardona', 'manuelac@example.com', '99001', 4),
(10058243, 'Jorge Quintero', 'jorgeq@example.com', '10101', 1),
(10058244, 'Juliana Vargas', 'julianav@example.com', '20202', 4),
(10058245, 'Ricardo Salazar', 'ricardos@example.com', '20201', 2),
(10058246, 'Elena García', 'elenag@example.com', '30302', 1),
(10058247, 'Mario Rincón', 'marior@example.com', '40403', 3),
(10058248, 'Natalia Pardo', 'nataliap@example.com', '50504', 4),
(10058249, 'Andrés González', 'andresg@example.com', '60605', 1),
(10058250, 'Patricia Díaz', 'patriciad@example.com', '70706', 2),
(10058251, 'Camilo Torres', 'camilot@example.com', '80807', 4),
(10058252, 'Lorena Peña', 'lorenap@example.com', '90908', 3),
(10058253, 'Javier Méndez', 'javierm@example.com', '10109', 2),
(10058254, 'Marcela Romero', 'marcelar@example.com', '20210', 1),
(10058255, 'Héctor Valdés', 'hectorv@example.com', '30311', 4),
(10058256, 'Tatiana Lozano', 'tatianal@example.com', '40412', 3),
(10058257, 'Santiago Herrera', 'santiagoh@example.com', '50513', 1),
(10058258, 'Carolina Fajardo', 'carolinaf@example.com', '60614', 2),
(10058259, 'Pablo Reyes', 'pablor@example.com', '70715', 4),
(10058260, 'Verónica Molina', 'veronicam@example.com', '80816', 3),
(10058261, 'Cristian Acosta', 'cristiana@example.com', '90917', 1),
(10058262, 'Gabriela León', 'gabrielal@example.com', '10118', 2),
(10058263, 'Rodrigo Céspedes', 'rodrigoc@example.com', '20219', 4),
(10058264, 'Mónica Serrano', 'monicas@example.com', '30320', 1),
(10058265, 'Esteban Vargas', 'estebanv@example.com', '40421', 2),
(10058266, 'Daniela Hoyos', 'danielah@example.com', '50522', 3),
(10058267, 'Luis Ávila', 'luisa@example.com', '60623', 4),
(10058268, 'Claudia Prieto', 'claudiap@example.com', '70724', 1),
(10058269, 'Sebastián Mora', 'sebastianm@example.com', '80825', 2),
(10058270, 'Valeria Jiménez', 'valeriaj@example.com', '90926', 3),
(10058271, 'Tomás Parra', 'tomasp@example.com', '10127', 4),
(10058272, 'Nataly Castaño', 'natalyc@example.com', '20228', 1),
(10058273, 'Iván Rosas', 'ivanr@example.com', '30329', 2),
(10058274, 'Isabel Rico', 'isabelr@example.com', '40430', 3),
(10058275, 'Álvaro Medina', 'alvarom@example.com', '50531', 4),
(10058276, 'Camila Lozada', 'camilal@example.com', '60632', 1),
(10058277, 'Emilio Duarte', 'emiliod@example.com', '70733', 2),
(10058278, 'Lucía Campos', 'luciac@example.com', '80834', 3),
(10058279, 'Julián Montes', 'julianm@example.com', '90935', 4),
(10058280, 'Diana Espinosa', 'dianae@example.com', '10136', 1),
(10058281, 'Carlos Ibáñez', 'carlosi@example.com', '20237', 2),
(10058282, 'Renata Suárez', 'renatas@example.com', '30338', 3),
(10058283, 'Simón Navarro', 'simonn@example.com', '40439', 4),
(10058284, 'Paola Cortés', 'paolac@example.com', '50540', 1),
(10058285, 'Jonathan Vélez', 'jonathanv@example.com', '60641', 2),
(10058286, 'Adriana Paz', 'adrianap@example.com', '70742', 3),
(10058287, 'Mateo Rivas', 'mateor@example.com', '80843', 4),
(10058288, 'Laura Aguirre', 'lauraa@example.com', '90944', 1),
(10058289, 'Enrique Bustos', 'enriqueb@example.com', '10145', 2),
(10058290, 'Daniel Rojas', 'danielr@example.com', '20246', 3),
(10058291, 'Luisa Mejía', 'luisam@example.com', '30347', 4),
(10058292, 'Federico Niño', 'federicon@example.com', '40448', 1),
(10058293, 'Florencia Carrillo', 'florenciac@example.com', '50549', 2),
(10058294, 'Jorge Palacios', 'jorgep@example.com', '60650', 3),
(10058295, 'Melissa Blanco', 'melissab@example.com', '70751', 4),
(10058296, 'Ángel Roldán', 'angelr@example.com', '80852', 1),
(10058297, 'Sofía Londoño', 'sofial@example.com', '90953', 2),
(10058298, 'Camilo Mejía', 'camilomj@example.com', '10154', 3),
(10058299, 'Alejandra Pinto', 'alejandrap@example.com', '20255', 4),
(10058300, 'Felipe Navarro', 'felipen@example.com', '30356', 1),
(10058301, 'Margarita Pineda', 'margaritap@example.com', '40457', 2),
(10058302, 'Guillermo Torres', 'guillermot@example.com', '50558', 3),
(10058303, 'Rosa Díaz', 'rosad@example.com', '60659', 4),
(10058304, 'Ignacio Bravo', 'ignaciob@example.com', '70760', 1),
(10058305, 'Carmen Ortega', 'carmeno@example.com', '80861', 2),
(10058306, 'Oscar Leiva', 'oscarl@example.com', '90962', 3),
(10058307, 'Daniela Barrios', 'danielab@example.com', '10163', 4),
(10058308, 'Raúl Cárdenas', 'raulc@example.com', '20264', 1),
(10058309, 'Antonia Medina', 'antoniam@example.com', '30365', 2),
(10058310, 'Marcos Núñez', 'marcosn@example.com', '40466', 3),
(10058311, 'Violeta Cano', 'violetac@example.com', '50567', 4),
(10058312, 'Samuel Ortega', 'samuelor@example.com', '60668', 1),
(10058313, 'Luciana Díaz', 'lucianad@example.com', '70769', 2),
(10058314, 'Francisco Cruz', 'franciscoc@example.com', '80870', 3),
(10058315, 'Inés Salinas', 'iness@example.com', '90971', 4),
(10058316, 'Martín Zamora', 'martinz@example.com', '10172', 1),
(10058317, 'Pilar Andrade', 'pilaran@example.com', '20273', 2),
(10058318, 'Benjamín Saavedra', 'benjamins@example.com', '30374', 3),
(10058319, 'Catalina Varela', 'catalinav@example.com', '40475', 4),
(10058320, 'Hugo Espinoza', 'hugoe@example.com', '50576', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `medio_pago_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `fecha`, `cliente_id`, `medio_pago_id`) VALUES
(1, '2025-05-01', 1, 1),
(2, '2025-05-02', 3, 3),
(3, '2025-05-02', 4, 2),
(4, '2025-05-03', 6, 4),
(5, '2025-05-03', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_compras`
--

CREATE TABLE `ventas_compras` (
  `id` int(11) NOT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `compra_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas_compras`
--

INSERT INTO `ventas_compras` (`id`, `venta_id`, `compra_id`) VALUES
(101, 1, 1),
(102, 2, 2),
(103, 3, 3),
(104, 4, 4),
(105, 5, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proveedor_id` (`proveedor_id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `medio_pago_id` (`medio_pago_id`);

--
-- Indices de la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `compra_id` (`compra_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venta_id` (`venta_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `medios_pago`
--
ALTER TABLE `medios_pago`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indices de la tabla `productos_clientes`
--
ALTER TABLE `productos_clientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_rol_id` (`rol_id`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `medio_pago_id` (`medio_pago_id`);

--
-- Indices de la tabla `ventas_compras`
--
ALTER TABLE `ventas_compras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venta_id` (`venta_id`),
  ADD KEY `compra_id` (`compra_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `medios_pago`
--
ALTER TABLE `medios_pago`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `productos_clientes`
--
ALTER TABLE `productos_clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9813;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10058321;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ventas_compras`
--
ALTER TABLE `ventas_compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`),
  ADD CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `compras_ibfk_3` FOREIGN KEY (`medio_pago_id`) REFERENCES `medios_pago` (`id`);

--
-- Filtros para la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  ADD CONSTRAINT `detalle_compras_ibfk_1` FOREIGN KEY (`compra_id`) REFERENCES `compras` (`id`),
  ADD CONSTRAINT `detalle_compras_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD CONSTRAINT `detalle_venta_ibfk_1` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`id`),
  ADD CONSTRAINT `detalle_venta_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Filtros para la tabla `productos_clientes`
--
ALTER TABLE `productos_clientes`
  ADD CONSTRAINT `productos_clientes_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `productos_clientes_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_rol_id` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`),
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`medio_pago_id`) REFERENCES `medios_pago` (`id`);

--
-- Filtros para la tabla `ventas_compras`
--
ALTER TABLE `ventas_compras`
  ADD CONSTRAINT `ventas_compras_ibfk_1` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`id`),
  ADD CONSTRAINT `ventas_compras_ibfk_2` FOREIGN KEY (`compra_id`) REFERENCES `compras` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
